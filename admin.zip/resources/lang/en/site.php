<?php return array (
  'OK' => 'OK',
  'Please try again' => 'Please try again',
);