<?php $__env->startSection('content'); ?>

<div class="card card-custom gutter-b">
    <div class="card-header">
        <div class="card-title">
            <h3 class="card-label">
                تعديل البيانات الشخصية
            </h3>
        </div>
        <div class="card-toolbar">
           
        </div>
    </div>
    <div class="card-body">
        <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                <strong>!</strong> الاخطاء <br><br>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

            <?php echo Form::model(auth()->user(), ['method' => 'POST','route' => ['updateProfile'] , 'files' => true]); ?>

            <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>الاسم:</strong>
                    <?php echo Form::text('name', null, array('placeholder' => 'الاسم','class' => 'form-control')); ?>

                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>البريد:</strong>
                    <?php echo Form::text('email', null, array('placeholder' => 'البريد الالكترونى','class' => 'form-control')); ?>

                </div>
            </div>
            <div class="col-xs-12 col-sm-12 my-3">

                <label>   الصوره :</label>
                <div class="custom-file">
                    <input type="file" name="image" class="custom-file-input form-control"/>
                </div>
            </div>

            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>كلمة المرور :</strong>
                    <?php echo Form::password('password', array('placeholder' => 'كلمة المرور','class' => 'form-control')); ?>

                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>تاكيد كلمة المرور:</strong>
                    <?php echo Form::password('confirm-password', array('placeholder' => 'تاكيد كلمة المرور','class' => 'form-control')); ?>

                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 text-center my-5">
                <button type="submit" class="btn btn-primary">ارسال </button>
            </div>
        </div>
        <?php echo Form::close(); ?>



    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dfj2e8tn2by3/public_html/backlinko.yaqoutinfo.com/resources/views/admin/user/profile.blade.php ENDPATH**/ ?>