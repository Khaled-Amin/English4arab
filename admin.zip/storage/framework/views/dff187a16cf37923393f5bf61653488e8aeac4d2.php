



<?php $__env->startSection('content'); ?>

<div class="card card-custom gutter-b">
    <div class="card-header">
        <div class="card-title">
            <h3 class="card-label">
                Edit User
            </h3>
        </div>
        <div class="card-toolbar">
           
        </div>
    </div>
    <div class="card-body">
        <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                <strong>Whoops!</strong> There were some problems with your input.<br><br>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

            <?php echo Form::model(auth()->user(), ['method' => 'POST','route' => ['updateProfile'] , 'files' => true]); ?>

            <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Name:</strong>
                    <?php echo Form::text('name', null, array('placeholder' => 'Name','class' => 'form-control')); ?>

                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Email:</strong>
                    <?php echo Form::text('email', null, array('placeholder' => 'Email','class' => 'form-control')); ?>

                </div>
            </div>
            <div class="col-xs-12 col-sm-12 my-3">

                <label>Photo :</label>
                <div class="custom-file">
                    <input type="file" name="image" class="custom-file-input"/>
                    <label class="custom-file-label" for="customFile">Choose file</label>
                </div>
            </div>

            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-6">
                </div>
            </div>

            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Password:</strong>
                    <?php echo Form::password('password', array('placeholder' => 'Password','class' => 'form-control')); ?>

                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Confirm Password:</strong>
                    <?php echo Form::password('confirm-password', array('placeholder' => 'Confirm Password','class' => 'form-control')); ?>

                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </div>
        <?php echo Form::close(); ?>



    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\lessons_coupon\resources\views/admin/user/profile.blade.php ENDPATH**/ ?>