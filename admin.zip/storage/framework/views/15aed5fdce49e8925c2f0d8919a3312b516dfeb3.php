<div class="toolbar d-flex flex-stack mb-3 mb-lg-5" id="kt_toolbar">
    <!--begin::Container-->
    <div id="kt_toolbar_container" class="container-fluid d-flex flex-stack flex-wrap">
        <!--begin::Page title-->
        <div class="page-title d-flex flex-column me-5 py-2">
            <!--begin::Title-->
            <h1 class="d-flex flex-column text-dark fw-bolder fs-3 mb-0"><?php echo e(@$title); ?></h1>
            <!--end::Title-->
            <!--begin::Breadcrumb-->
            <ul class="breadcrumb breadcrumb-separatorless fw-bold fs-7 pt-1">
                <?php if(isset($li)): ?>
                <?php $__currentLoopData = $li; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="breadcrumb-item text-muted">
                    <a href="<?php echo e(@$item[1]); ?>" class="text-muted text-hover-primary"><?php echo e(@$item[0]); ?></a>
                </li>
                <li class="breadcrumb-item">
                    <span class="bullet bg-gray-200 w-5px h-2px"></span>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </ul>
            <!--end::Breadcrumb-->
        </div>
        <!--end::Page title-->
        <!--begin::Actions-->
        <div class="d-flex align-items-center py-2">
            <?php echo $__env->yieldContent('options'); ?>
        </div>
        <!--end::Actions-->
    </div>
    <!--end::Container-->
</div><?php /**PATH /home/dfj2e8tn2by3/public_html/backlinko.yaqoutinfo.com/resources/views/layouts/elements/subheader.blade.php ENDPATH**/ ?>