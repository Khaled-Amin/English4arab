<?php $__env->startSection('content'); ?>
    <section class="gen-section-padding-3">

        <div class="container">
            <div class="row no-gutters">
                <div class="col-lg-12">
                    <div class="gen-single-movie-wrapper style-1">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="gen-video-holder">
                                    <div class="video" 
                                        data-<?php echo e($lesson->type); ?>="<?php echo e($lesson->link); ?>"
                                    ></div>
                                </div>
                                <div class="gen-single-movie-info">
                                    <h2 class="gen-title"><?php echo e($section->title); ?> - <?php echo e($lesson->title); ?></h2>
                                    <?php echo $lesson->body; ?>

                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="pm-inner">
                                    <div class="gen-more-like">
                                        <h5 class="gen-more-title">دروس القسم</h5>
                                        <div class="row">
                                            <?php $__currentLoopData = $section->lessonsPagination; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currentLesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="col-xl-3 col-lg-4 col-md-6">
                                                    <div
                                                        class="gen-carousel-movies-style-1 movie-grid style-1 <?php echo e($currentLesson->id == $lesson->id ? 'active' : ''); ?> ">
                                                        <div class="gen-movie-contain">
                                                            <div class="gen-movie-img">
                                                                <img src="<?php echo e($currentLesson->imageUrl); ?>"
                                                                    alt="<?php echo e($currentLesson->title); ?>">
                                                                <div class="gen-movie-add">
    
                                                                </div>
                                                                <div class="gen-movie-action">
                                                                    <a href="/lesson/<?php echo e($currentLesson->id); ?>"
                                                                        class="gen-button">
                                                                        <i class="fa fa-play"></i>
                                                                    </a>
                                                                </div>
                                                            </div>
                                                            <div class="gen-info-contain">
                                                                <div class="gen-movie-info">
                                                                    <h3><a
                                                                            href="/lesson/<?php echo e($currentLesson->id); ?>"><?php echo e($currentLesson->title); ?></a>
                                                                    </h3>
                                                                </div>
                                                                <div class="gen-movie-meta-holder">
                                                                    <ul>
                                                                    </ul>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                    <div class="gen-pagination">
                                        <?php echo e($section->lessonsPagination->links('pagination::bootstrap-4')); ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('stack-js'); ?>
    <script src="/assets/js/videobox.min.js"></script>
    <script>
        $(".video").videoBox({
            height: '550',
            loop: false,
            autoplay: false,
            byline: true,
            color: "00adef",
            maxheight: '',
            maxwidth: '',
            portrait: true,
            title: '<?php echo e($lesson->title); ?>'
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dfj2e8tn2by3/public_html/backlinko.yaqoutinfo.com/resources/views/site/lesson.blade.php ENDPATH**/ ?>