<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>" dir="<?php echo e(app()->getLocale() == 'ar' ? 'rtl' : 'ltr'); ?>">

<head>
    <meta charset="utf-8">
    <meta name="keywords" content="Streamlab - Video Streaming HTML5 Template" />
    <meta name="description" content="Streamlab - Video Streaming HTML5 Template" />
    <meta name="author" content="StreamLab" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(settings('favicon')->value); ?>" />
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(settings('favicon')->value); ?>" />
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(settings('favicon')->value); ?>" />
    <link rel="shortcut icon" href="<?php echo e(settings('favicon')->value); ?>" />

    <meta name="apple-mobile-web-app-title" content="<?php echo e(settings('site_name')->value); ?>" />
    <meta name="application-name" content="<?php echo e(settings('site_name')->value); ?>" " />


    <title><?php echo e(@$section->title); ?> – <?php echo e(settings('site_name')->value); ?></title>
    <!-- Favicon -->
    <meta property=" og:url" content="site index | http://127.0.0.1:8000/" />
    <meta property="og:type" content="" />
    <meta property="og:title" content="<?php echo e(settings('site_name')->value); ?>" />
    <meta property="og:description" content="<?php echo e(settings('site_desk')->value); ?>" />
    <meta property="og:image:width" content="880" />
    <meta property="og:image:height" content="660" />
    <meta property="og:locale" content="<?php echo e(app()->getLocale()); ?>" />
    <!-- CSS bootstrap-->
    <link rel="stylesheet" href="/assets/css/bootstrap.min.css" />
    <!--  Style -->
    <link rel="stylesheet" href="/assets/css/style.css" />
    <!--  Responsive -->
    <link rel="stylesheet" href="/assets/css/responsive.css" />
</head>

<body>

    <!--=========== Loader =============-->
    <div id="gen-loading">
        <div id="gen-loading-center">
            <img src="<?php echo e(settings('loading')->value); ?>" alt="loading">
        </div>
    </div>
    <!--=========== Loader =============-->

    <!--========== Header ==============-->
    <header id="gen-header" class="gen-header-style-1 gen-has-sticky">
        <div class="gen-bottom-header">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <nav class="navbar navbar-expand-lg navbar-light">
                            <a class="navbar-brand" href="#">
                                <img class="img-fluid logo" src="/assets/images/logo-1.png" alt="streamlab-image">
                            </a>

                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!--========== Header ==============-->

    <!-- breadcrumb -->
    <div class="gen-breadcrumb" style="background-image: url('images/background/asset-25.jpeg');">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-12">
                    <nav aria-label="breadcrumb">
                        <div class="gen-breadcrumb-title">
                            <h1>
                                <?php echo e(settings('site_name')->value); ?>

                            </h1>
                        </div>
                        <?php if(isset($section)): ?>
                            <div class="gen-breadcrumb-container">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item">
                                        <a href="/">
                                            <i class="fas fa-home mr-2"></i>Home</a>
                                    </li>
                                    <li class="breadcrumb-item active">
                                       <a href="<?php echo e($section->title); ?>"><?php echo e($section->title); ?></a>
                                    </li>
                                </ol>
                            </div>
                        <?php endif; ?>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <!-- breadcrumb -->

    <!-- Videos Style 1 -->
        <?php echo $__env->yieldContent('content'); ?>
    <!-- Videos Style 1 -->

    <!-- footer start -->
    <footer id="gen-footer">
        <div class="gen-footer-style-1">
            <div class="">
                    <div class=" justify-content-center text-center">
                        <img src="<?php echo e(settings('logo')->value); ?>" class="gen-footer-logo" alt="gen-footer-logo">
                    </div>
           </div>
            <div class="gen-copyright-footer">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12 align-self-center">
                            <span class="gen-copyright"><a> <?php echo e(settings('footer_desk')->value); ?> </a></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- footer End -->

    <!-- Back-to-Top start -->
    <div id="back-to-top">
        <a class="top" id="top" href="#top"> <i class="ion-ios-arrow-up"></i> </a>
    </div>
    <!-- Back-to-Top end -->

    <!-- js-min -->
    <script src="/assets/js/jquery-3.6.0.min.js"></script>
    <script src="/assets/js/asyncloader.min.js"></script>
    <!-- JS bootstrap -->
    <script src="/assets/js/bootstrap.min.js"></script>
    <!-- owl-carousel -->
    <script src="/assets/js/owl.carousel.min.js"></script>
    <!-- counter-js -->
    <script src="/assets/js/jquery.waypoints.min.js"></script>
    <script src="/assets/js/jquery.counterup.min.js"></script>
    <!-- popper-js -->
    <script src="/assets/js/popper.min.js"></script>
    <script src="/assets/js/swiper-bundle.min.js"></script>
    <!-- Iscotop -->
    <script src="/assets/js/isotope.pkgd.min.js"></script>

    <script src="/assets/js/jquery.magnific-popup.min.js"></script>

    <script src="/assets/js/slick.min.js"></script>

    <script src="/assets/js/streamlab-core.js"></script>

    <script src="/assets/js/script.js"></script>
<?php echo $__env->yieldPushContent('stack-js'); ?>

</body>

</html>
<?php /**PATH D:\Laravel\lessons_coupon\resources\views/layouts/site.blade.php ENDPATH**/ ?>