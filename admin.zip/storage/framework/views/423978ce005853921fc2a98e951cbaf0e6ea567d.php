<?php $__env->startSection('content'); ?>
<section class="gen-section-padding-3">
    
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="row">
                <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-xl-3 col-lg-4 col-md-6">
                        <div class="gen-carousel-movies-style-1 movie-grid style-1">
                            <div class="gen-movie-contain">
                                <div class="gen-movie-img">
                                    <img src="<?php echo e($section1->imageUrl); ?>" alt="<?php echo e($section1->title); ?>">
                                    <div class="gen-movie-add">
                                        
                                    </div>
                                    <div class="gen-movie-action">
                                        <a 
                                        
                                        href="/<?php echo e($section1->slug); ?>" 
                                        
                                            
                                        
                                        class="gen-button">
                                            <i class="fa fa-play"></i>
                                        </a>
                                    </div>
                                </div>
                                <div class="gen-info-contain">
                                    <div class="gen-movie-info">
                                        <h3><a   <?php if($section1->auth()): ?>
                                        href="/<?php echo e($section1->slug); ?>" 
                                        <?php else: ?>
                                            
                                        <?php endif; ?> 
                                        ><?php echo e($section1->title); ?></a></h3>
                                    </div>
                                    <div class="gen-movie-meta-holder">
                                        <ul>
                                            <li><?php echo e($section1->lessons()->count()); ?> درس </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="row">
                    <div class="col-lg-12 col-md-12">
                        <div class="gen-pagination">   
                            <?php echo e($sections->links("pagination::bootstrap-4")); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dfj2e8tn2by3/public_html/backlinko.yaqoutinfo.com/resources/views/site/index.blade.php ENDPATH**/ ?>